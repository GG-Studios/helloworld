#include<bits/stdc++.h>
#include<windows.h>
#include<conio.h>
#define init register int
#define inf 1000000000
#define LL long long
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
#define teacher ''
#define student ''
using namespace std;
char mp[1005][1005]={};
int n=10,m=20,fx[5]={0,-1,0,1,0},fy[5]={0,0,1,0,-1};
int tc[4][4]={},vvv=10000;
int xx,yy,ct;
void gotoXY(short x, short y)
{
	x^=y^=x^=y;
    COORD pos = {x, y};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hOut, pos);
}
void GO();
void WIN();
void LOSE();
void BAD();
int pre();
int main()
{
	CONSOLE_CURSOR_INFO cursor_info = {1, 0}; 
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
	srand(time(NULL));
	printf("���볤����");
	cin>>n>>m;
	printf("������ʦ������");
	cin>>ct;
	system("cls");
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=m;j++)
		{
			if(i==0||j==0||i==n||j==m)mp[i][j]='+';
			else mp[i][j]=' ';
		}
	}
	back:;
	int vx=rand()%n+1,vy=rand()%m+1;
	if(mp[vx][vy]==' ')mp[vx][vy]='%';
	else goto back;
	backc:;
	xx=rand()%n+1,yy=rand()%m+1;
	if(mp[xx][yy]!=' ')goto backc;
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=m;j++)
		{
			if(mp[i][j]==' '&&rand()%5==0)mp[i][j]='+';
			putchar(mp[i][j]);
		}
		putchar('\n');
	}
	for(int i=1;i<=ct;i++)
	{
		back2:;
		tc[i][1]=rand()%n+1,tc[i][2]=rand()%m+1;
		if(mp[tc[i][1]][tc[i][2]]!=' ')goto back2;
		tc[i][3]=vvv;
		tc[i][4]=rand()%4+1;
		gotoXY(tc[i][1],tc[i][2]),putchar(teacher);
	}
	gotoXY(xx,yy);
	putchar(student);
	while(1)
	{
		GO();
		int lx=xx,ly=yy;
		if(_kbhit())
		{
			char ch=_getch();
			if(ch=='w')
			{
				if(mp[xx-1][yy]==' ')xx--;
				else if(mp[xx-1][yy]=='%')WIN();
				gotoXY(lx,ly);
				putchar(' ');
				gotoXY(xx,yy);
				putchar(student);
			}
			if(ch=='s')
			{
				if(mp[xx+1][yy]==' ')xx++;
				else if(mp[xx+1][yy]=='%')WIN();
				gotoXY(lx,ly);
				putchar(' ');
				gotoXY(xx,yy);
				putchar(student);
			}
			if(ch=='a')
			{
				if(mp[xx][yy-1]==' ')yy--;
				else if(mp[xx][yy-1]=='%')WIN();
				gotoXY(lx,ly);
				putchar(' ');
				gotoXY(xx,yy);
				putchar(student);
			}
			if(ch=='d')
			{
				if(mp[xx][yy+1]==' ')yy++;
				else if(mp[xx][yy+1]=='%')WIN();
				gotoXY(lx,ly);
				putchar(' ');
				gotoXY(xx,yy);
				putchar(student);
			}
		}
	}
}
int pre(int xx1,int yy1,int xx2,int yy2,int ff)
{
	if(mp[xx1][yy1]!=' ')return -inf;
	if(xx1==xx2&&yy1==yy2)return 1;
	return pre(xx1+fx[ff],yy1+fy[ff],xx2,yy2,ff)+1;
}
void BAD()
{
	system("color 04");
	vvv=10;
}
void GO()
{
	for(int i=1;i<=ct;i++)
	{
		tc[i][3]--;
		if(tc[i][1]==xx&&tc[i][2]==yy)LOSE();
		if(tc[i][3]>vvv)tc[i][3]=vvv;
		if(tc[i][3]==0)
		{
			tc[i][3]=vvv;
			if(mp[tc[i][1]+fx[tc[i][4]]][tc[i][2]+fy[tc[i][4]]]==' ')
			{
				gotoXY(tc[i][1],tc[i][2]);
				putchar(' ');
				tc[i][1]+=fx[tc[i][4]];
				tc[i][2]+=fy[tc[i][4]];
				gotoXY(tc[i][1],tc[i][2]);
				putchar(teacher);
			}
			else
			{
				tc[i][4]=rand()%4+1;
			}
		}
		if(pre(xx,yy,tc[i][1],tc[i][2],1)>0||pre(xx,yy,tc[i][1],tc[i][2],3)>0)BAD();
		if(pre(xx,yy,tc[i][1],tc[i][2],2)>0||pre(xx,yy,tc[i][1],tc[i][2],4)>0)BAD();
	}
}
void WIN()
{
	system("cls");
	system("color 02");
	printf("YOU WIN!\n\n");
	system("pause");
	exit(0);
}
void LOSE()
{
	system("cls");
	printf("YOU LOSE\n\n");
	system("pause");
	exit(0);
}
